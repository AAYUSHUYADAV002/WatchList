package watchListify.watchList.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class StringUtil {

   
    public static boolean isEmpty(String str) {
        return str == null || "".equals(str.trim());
    }

    public static boolean isNotEmpty(String str) {
        return str != null && !"".equals(str.trim());
    }


    public static List<String> filterWhite(List<String> list) {
        List<String> resultList = new ArrayList<String>();
        for (String l : list) {
            if (isNotEmpty(l))
                resultList.add(l);
        }
        return resultList;
    }

   
    public static String formatLike(String str) {
        if (isNotEmpty(str))
            return "%" + str + "%";
        else
            return null;
    }

    public static void main(String[] args) {
        String str1 = "  abc  ";
        str1 = str1.trim();
        String str2 = "abc";
        System.out.println(str1 == str2);
        System.out.println(Objects.equals(str1, str2));
    }


}