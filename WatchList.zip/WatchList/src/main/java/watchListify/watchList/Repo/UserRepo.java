package watchListify.watchList.Repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import watchListify.watchList.entity.User;

	@Repository
	 public interface UserRepo  extends JpaRepository<User, String>{

	    Optional<User> findByuserName( String UserName);
	}
