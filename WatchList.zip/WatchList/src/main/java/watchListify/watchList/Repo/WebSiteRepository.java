package watchListify.watchList.Repo;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import watchListify.watchList.entity.WebSite;


public interface WebSiteRepository extends JpaRepository<WebSite, Integer>, JpaSpecificationExecutor<WebSite> {
}