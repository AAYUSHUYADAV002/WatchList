package watchListify.watchList.Repo;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import watchListify.watchList.entity.WebSiteInfo;

import java.util.List;


public interface WebSiteInfoRepository extends JpaRepository<WebSiteInfo, Integer>, JpaSpecificationExecutor<WebSiteInfo> {

   
    @Query(value = "select * from t_info where film_id=?1", nativeQuery = true)
    List<WebSiteInfo> getByFilmId(Integer filmId);

   
    @Query(value = "select * from t_info where web_site_id=?1", nativeQuery = true)
    List<WebSiteInfo> getByWebSiteId(Integer webSiteId);
}