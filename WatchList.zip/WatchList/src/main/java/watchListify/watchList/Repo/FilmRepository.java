package watchListify.watchList.Repo;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import watchListify.watchList.entity.Film;

import java.util.List;


public interface FilmRepository extends JpaRepository<Film, Integer>, JpaSpecificationExecutor<Film> {

   
    @Query(value = "SELECT * FROM t_film where id <?1 ORDER BY id DESC limit 1", nativeQuery = true)
    Film getLastFilm(Integer id);

    @Query(value = "SELECT * FROM t_film where id >?1 ORDER BY id ASC limit 1", nativeQuery = true)
    Film getNextFilm(Integer id);

    @Query(value = "SELECT * FROM t_film ORDER BY rand() limit ?1",nativeQuery = true)
    List<Film> randomList(Integer n);
}