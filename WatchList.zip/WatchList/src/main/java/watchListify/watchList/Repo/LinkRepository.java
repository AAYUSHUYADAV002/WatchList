package watchListify.watchList.Repo;



import org.springframework.data.jpa.repository.JpaRepository;

import watchListify.watchList.entity.Link;


public interface LinkRepository extends JpaRepository<Link,Integer> {

}