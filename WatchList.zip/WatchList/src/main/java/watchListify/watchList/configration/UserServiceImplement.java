package watchListify.watchList.configration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import watchListify.watchList.Repo.UserRepo;
import watchListify.watchList.entity.User;


@Service
public class UserServiceImplement implements UserDetailsService {

	@Autowired 
	  private UserRepo userRepo;
	  

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {


		User use = userRepo.findByuserName(username).orElseThrow(()-> new UsernameNotFoundException("Data not found"));
	

		
		
//		if (users == null) {
//			throw new UsernameNotFoundException("Username Not Found !!! Try another user name or create new account.");
//		}
	

		CustomUserDetels customUserDetels = new CustomUserDetels(use);

		return customUserDetels;

	
	}

}
