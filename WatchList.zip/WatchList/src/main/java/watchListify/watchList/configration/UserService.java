package watchListify.watchList.configration;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import watchListify.watchList.Repo.UserRepo;
import watchListify.watchList.entity.User;

@Service
public class UserService {

	@Autowired 
	  private UserRepo userRepo;
	
	public List<User> getUsers(){
		return userRepo.findAll();
		
	}
	
	
}
