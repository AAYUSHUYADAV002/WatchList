package watchListify.watchList.configration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.stereotype.Controller;

import watchListify.watchList.security.*;


@Controller
@EnableWebSecurity
public class UserdetalsConfig {

	// Autowiring
  @Autowired
   public UserDetailsService userDetailsService ;
  

  @Autowired
  private JwtAuthenticationEntryPoint point;
  
  
  @Autowired
  private JwtAuthenticationFilter filter;


	// beans
  
	@Bean
	private BCryptPasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
		
	}
	


	
	 @Bean
	    public AuthenticationManager authenticationManager(AuthenticationConfiguration builder) throws Exception {
	        return builder.getAuthenticationManager();
	    }

	@Bean
	public DaoAuthenticationProvider authenticationProvider() {
		DaoAuthenticationProvider DaoAuthenticationProvider = new DaoAuthenticationProvider();
		DaoAuthenticationProvider.setUserDetailsService(userDetailsService);
		DaoAuthenticationProvider.setPasswordEncoder(passwordEncoder());
		return DaoAuthenticationProvider;
	}

	
	

	@Bean
	@Order(1)
	public SecurityFilterChain SecurityFilterChain(HttpSecurity http) throws Exception {
		http.csrf(csrf -> csrf.disable())
		.securityMatcher("/Admin/**")                                   
		.authorizeHttpRequests(authorize -> authorize
			.anyRequest().hasRole("ADMIN")
		)  
		 .exceptionHandling(ex -> ex.authenticationEntryPoint(point))
	      .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS));
	http.addFilterBefore(filter, UsernamePasswordAuthenticationFilter.class)
		
		.httpBasic(Customizer.withDefaults())
		.formLogin(form -> form
				.loginPage("/singin").permitAll());
	//authorizeHttpRequest.requestMatchers("/Admin/**").hasRole("Admin").requestMatchers("/NUser").hasRole("Normal").requestMatchers("/**").permitAll().and().formLogin();
		return http.build();
	}
	
	@Bean

	@Order(2)
	public SecurityFilterChain SecurityFilterChainUser(HttpSecurity http) throws Exception {
		http.csrf(csrf -> csrf.disable()).securityMatcher("/User/**")
				.authorizeHttpRequests(authorize -> authorize.anyRequest().hasRole("NORMAL"))
				.exceptionHandling(ex -> ex.authenticationEntryPoint(point))
				.sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS));
		http.addFilterBefore(filter, UsernamePasswordAuthenticationFilter.class).httpBasic(Customizer.withDefaults())
				.formLogin(form -> form.loginPage("/singin").permitAll());
		return http.build(); }
	 
	
	@Bean                                 
	@Order(3)
	public SecurityFilterChain formLoginFilterChain(HttpSecurity http) throws Exception {
		http.csrf(csrf -> csrf.disable())
		.securityMatcher("/**")  
			.authorizeHttpRequests(authorize -> authorize
				.anyRequest().permitAll()
			)
			.exceptionHandling(ex -> ex.authenticationEntryPoint(point))
		      .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS));
		http.addFilterBefore(filter, UsernamePasswordAuthenticationFilter.class)
			.httpBasic(Customizer.withDefaults())
			.formLogin(form -> form
					.loginPage("/singin"));
		return http.build();
	}

}
