package watchListify.watchList.service;


import java.util.List;

import watchListify.watchList.entity.WebSite;


public interface WebSiteService {

  
    List<WebSite> list(WebSite webSite, Integer page, Integer pageSize);

  
    Long getCount(WebSite webSite);

    void save(WebSite webSite);

    void delete(Integer id);

    List<WebSite> newestList(Integer page, Integer pageSize);
}