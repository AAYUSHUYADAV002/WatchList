package watchListify.watchList.service.impl;



import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import jakarta.annotation.Resource;
import jakarta.persistence.criteria.Predicate;
import watchListify.watchList.Repo.FilmRepository;
import watchListify.watchList.entity.Film;
import watchListify.watchList.service.FilmService;
import watchListify.watchList.util.StringUtil;

import java.util.List;



@Service("filmService")
public class FilmServiceImpl implements FilmService {

    @Resource
    private FilmRepository filmRepository;

    @Override
    public void save(Film film) {
        filmRepository.save(film);
    }

    @Override
    public List<Film> list(Film film, Integer page, Integer pageSize) {
    	Pageable pageable = PageRequest.of(page, pageSize, Sort.by(Sort.Direction.DESC, "publishDate"));
        Page<Film> filmPage = filmRepository.findAll((root, criteriaQuery, cb) -> {
            Predicate predicate = cb.conjunction();
            if (film != null) {
                if (StringUtil.isNotEmpty(film.getName()))
                    predicate.getExpressions().add(cb.like(root.get("name"), "%" + film.getName().trim() + "%"));
               

            }
            return predicate;
        }, pageable);
        return filmPage.getContent();
    }

    @Override
    public Long getCount(Film film) {
        return filmRepository.count((root, criteriaQuery, cb) -> {
            Predicate predicate = cb.conjunction();
            if (film != null) {
                if (StringUtil.isNotEmpty(film.getName()))
                    predicate.getExpressions().add(cb.like(root.get("name"), "%" + film.getName().trim() + "%"));
              
                }
            
            return predicate;
        });
    }

    @Override
    public void delete(Integer id) {
        filmRepository.deleteById(id);
    }

//    @Override
//    public Film findById(Integer id) {
//        return filmRepository.findById(id);
//    }

    @Override
    public Film getLastFilm(Integer id) {
        return filmRepository.getLastFilm(id);
    }

    @Override
    public Film getNextFilm(Integer id) {
        return filmRepository.getNextFilm(id);
    }

    @Override
    public List<Film> randomList(Integer n) {
        return filmRepository.randomList(n);
    }

	@Override
	public Film findById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}
}