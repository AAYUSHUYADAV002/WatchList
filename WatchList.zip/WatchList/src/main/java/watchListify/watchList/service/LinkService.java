package watchListify.watchList.service;


import java.util.List;

import watchListify.watchList.entity.Link;


public interface LinkService {

 
    List<Link> list(Integer page, Integer pageSize);

   
    List<Link> listAll();

   
    Long getCount();

   
    void save(Link link);

    void delete(Integer id);
}