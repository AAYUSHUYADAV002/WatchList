package watchListify.watchList.service;


import java.util.List;

import watchListify.watchList.entity.WebSiteInfo;


public interface WebSiteInfoService {

   
    void save(WebSiteInfo webSiteInfo);

  
    List<WebSiteInfo> list(WebSiteInfo webSiteInfo, Integer page, Integer pageSize);

    Long getCount(WebSiteInfo webSiteInfo);

   
    List<WebSiteInfo> getByFilmId(Integer filmId);

    
    List<WebSiteInfo> getByWebSiteId(Integer webSiteId);

   
    void delete(Integer id);

}