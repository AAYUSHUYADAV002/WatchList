package watchListify.watchList.service.impl;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import jakarta.annotation.Resource;
import jakarta.persistence.criteria.Predicate;
import watchListify.watchList.Repo.WebSiteRepository;
import watchListify.watchList.entity.WebSite;
import watchListify.watchList.service.WebSiteService;
import watchListify.watchList.util.StringUtil;

import java.util.List;


@Service
public class WebSiteServiceImpl implements WebSiteService {

    @Resource
    private WebSiteRepository webSiteRepository;

    @Override
    public List<WebSite> list(WebSite webSite, Integer page, Integer pageSize) {
    	Pageable pageable = PageRequest.of(page, pageSize, Sort.by(Sort.Direction.ASC, "id"));

//        Pageable pageable = new PageRequest(page, pageSize, Sort.Direction.ASC, "id");
        Page<WebSite> webSitePage = webSiteRepository.findAll((root, criteriaQuery, cb) -> {
            Predicate predicate = cb.conjunction();
            if (webSite != null) {
                if (StringUtil.isNotEmpty(webSite.getName()))
                    predicate.getExpressions().add(cb.like(root.get("name"), "%" + webSite.getName().trim() + "%"));
                if (StringUtil.isNotEmpty(webSite.getUrl()))
                    predicate.getExpressions().add(cb.like(root.get("url"), "%" + webSite.getUrl().trim() + "%"));
            }
            return predicate;
        }, pageable);
        return webSitePage.getContent();
    }

    @Override
    public Long getCount(WebSite webSite) {
        Long count = webSiteRepository.count((root, criteriaQuery, cb) -> {
            Predicate predicate=cb.conjunction();
            if(webSite!=null){
                if(StringUtil.isNotEmpty(webSite.getName())){
                    predicate.getExpressions().add(cb.like(root.get("name"), "%"+webSite.getName().trim()+"%"));
                }
                if(StringUtil.isNotEmpty(webSite.getUrl())){
                    predicate.getExpressions().add(cb.like(root.get("url"), "%"+webSite.getUrl().trim()+"%"));
                }
            }
            return predicate;
        });
        return count;
    }

    @Override
    public void save(WebSite webSite) {
        webSiteRepository.save(webSite);
    }

    @Override
    public void delete(Integer id) {
        webSiteRepository.deleteById(id);
    }

    @Override
    public List<WebSite> newestList(Integer page, Integer pageSize) {
    	Pageable pageable = PageRequest.of(page, pageSize, Sort.by(Sort.Direction.ASC, "id"));

//        Pageable pageable=new PageRequest(page, pageSize,Sort.Direction.DESC,"id");
        return webSiteRepository.findAll(pageable).getContent();
    }
}