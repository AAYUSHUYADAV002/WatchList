package watchListify.watchList.service.impl;



import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import jakarta.annotation.Resource;
import jakarta.persistence.criteria.Predicate;
import watchListify.watchList.Repo.WebSiteInfoRepository;
import watchListify.watchList.entity.WebSiteInfo;
import watchListify.watchList.service.WebSiteInfoService;
import watchListify.watchList.util.StringUtil;

import java.util.List;


@Service("webSiteInfoService")
public class WebSiteInfoServiceImpl implements WebSiteInfoService{

    @Resource
    private WebSiteInfoRepository webSiteInfoRepository;

    @Override
    public void save(WebSiteInfo webSiteInfo) {
        webSiteInfoRepository.save(webSiteInfo);
    }

    @Override
    public List<WebSiteInfo> list(WebSiteInfo webSiteInfo, Integer page, Integer pageSize) {
    	Pageable pageable = PageRequest.of(page, pageSize, Sort.by(Sort.Direction.DESC, "publishDate"));

//        Pageable pageable=new PageRequest(page, pageSize, Sort.Direction.DESC,"publishDate");
        Page<WebSiteInfo> pageWebSite=webSiteInfoRepository.findAll((root, query, cb) -> {
            Predicate predicate=cb.conjunction();
            if(webSiteInfo!=null){
                if(StringUtil.isNotEmpty(webSiteInfo.getInfo())){
                    predicate.getExpressions().add(cb.like(root.get("info"), "%"+webSiteInfo.getInfo().trim()+"%"));
                }
            }
            return predicate;
        }, pageable);
        return pageWebSite.getContent();
    }

    @Override
    public Long getCount(WebSiteInfo webSiteInfo) {
        return webSiteInfoRepository.count((root, query, cb) -> {
            Predicate predicate=cb.conjunction();
            if(webSiteInfo!=null){
                if(StringUtil.isNotEmpty(webSiteInfo.getInfo())){
                    predicate.getExpressions().add(cb.like(root.get("info"), "%"+webSiteInfo.getInfo().trim()+"%"));
                }
            }
            return predicate;
        });
    }

    @Override
    public List<WebSiteInfo> getByFilmId(Integer filmId) {
        return webSiteInfoRepository.getByFilmId(filmId);
    }

    @Override
    public List<WebSiteInfo> getByWebSiteId(Integer webSiteId) {
        return webSiteInfoRepository.getByWebSiteId(webSiteId);
    }

    @Override
    public void delete(Integer id) {
        webSiteInfoRepository.deleteById(id);
    }
}