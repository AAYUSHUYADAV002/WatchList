package watchListify.watchList.service;


import java.util.List;

import watchListify.watchList.entity.Film;


public interface FilmService {

 
    void save(Film film);

    List<Film> list(Film film, Integer page, Integer pageSize);

    Long getCount(Film film);

 
    void delete(Integer id);

  
    Film findById(Integer id);

    Film getLastFilm(Integer id);

    Film getNextFilm(Integer id);

    List<Film> randomList(Integer n);

}