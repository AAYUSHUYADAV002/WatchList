package watchListify.watchList.service.impl;



import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import jakarta.annotation.Resource;
import watchListify.watchList.Repo.LinkRepository;
import watchListify.watchList.entity.Link;
import watchListify.watchList.service.LinkService;

import java.util.List;


@Service("linkService")
public class LinkServiceImpl implements LinkService {

    @Resource
    private LinkRepository linkRepository;

    @Override
    public List<Link> list(Integer page, Integer pageSize) {
    	return linkRepository.findAll(PageRequest.of(page, pageSize)).getContent();

//        return linkRepository.findAll(new PageRequest(page, pageSize)).getContent();
    }

    @Override
    public List<Link> listAll() {
        return linkRepository.findAll();
    }

    @Override
    public Long getCount() {
        return linkRepository.count();
    }

    @Override
    public void save(Link link) {
        linkRepository.save(link);
    }

    @Override
    public void delete(Integer id) {
        linkRepository.deleteById(id);
    }
}