package watchListify.watchList.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import watchListify.watchList.util.CustomDateTimeSerializer;

import java.sql.Date;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;


@Entity
@Table(name = "t_info")
public class WebSiteInfo {

    @Id
    @GeneratedValue
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "filmId")
    private Film film;

    @ManyToOne
    @JoinColumn(name = "webSiteId")
    private WebSite webSite;

    @Column(length = 1000)
    private String info;

    @Column(length = 500)
    private String url;

    private Date publishDate;
    
   

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Film getFilm() {
        return film;
    }

    public void setFilm(Film film) {
        this.film = film;
    }

    public WebSite getWebSite() {
        return webSite;
    }

    public void setWebSite(WebSite webSite) {
        this.webSite = webSite;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
    
    @JsonSerialize(using = CustomDateTimeSerializer.class)
    public Date getPublishDate() {
        return publishDate;
    }

    public void setPublishDate(Date publishDate) {
        this.publishDate = publishDate;
    }

 

    @Override
    public String toString() {
        return "WebSiteInfo{" +
                "id=" + id +
                ", film=" + film +
                ", webSite=" + webSite +
                ", info='" + info + '\'' +
                ", url='" + url + '\'' +
                '}';
    }
}