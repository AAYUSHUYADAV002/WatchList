package watchListify.watchList.entity;

public class Jwtresponce {

    private String JwtToken;
    private String UserName;

    // Private constructor to prevent direct instantiation
    private Jwtresponce() {
    }

    public String getJwtToken() {
        return JwtToken;
    }

    public String getUserName() {
        return UserName;
    }

    @Override
    public String toString() {
        return "Jwtresponce [JwtToken=" + JwtToken + ", UserName=" + UserName + "]";
    }

    // Package-private Builder class
    public static class Builder {
        private String jwtToken;
        private String userName;

        public Builder jwtToken(String jwtToken) {
            this.jwtToken = jwtToken;
            return this;
        }

        public Builder userName(String userName) {
            this.userName = userName;
            return this;
        }

        public Jwtresponce build() {
            Jwtresponce jwtResponse = new Jwtresponce();
            jwtResponse.JwtToken = this.jwtToken;
            jwtResponse.UserName = this.userName;
            return jwtResponse;
        }
    }

    // Static method to create an instance of the builder
    public static Builder builder() {
        return new Builder();
    }

   
}
