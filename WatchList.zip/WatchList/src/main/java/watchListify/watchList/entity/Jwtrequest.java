package watchListify.watchList.entity;

public class Jwtrequest {

	private String UserName;
	private String Password;
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public Jwtrequest(String userName, String password) {
		super();
		UserName = userName;
		Password = password;
	}
	
	public Jwtrequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Jwtrequest [UserName=" + UserName + ", Password=" + Password + "]";
	}
	
	
}
