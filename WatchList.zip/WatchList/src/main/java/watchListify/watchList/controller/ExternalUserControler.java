package watchListify.watchList.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.Map.Entry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import watchListify.watchList.security.JwtHelper;

import watchListify.watchList.entity.*;
import  watchListify.watchList.Repo.UserRepo;
import jakarta.servlet.http.HttpSession;

@Controller
public class ExternalUserControler {
	
	Map<String, String> loginUser = new HashMap<>();
	
	
	@Autowired
	private UserRepo UserRepo;
	
	@Autowired
	private BCryptPasswordEncoder BCryptPasswordEncoder;

	@Autowired
	private AuthenticationManager manager;
	
	 
	@Autowired
	private JwtHelper helper;

	@Autowired
	private UserDetailsService userDetailsService;


	@GetMapping("/")
	public String LandingPage(Model model) {
		model.addAttribute("title", "home");
		return "LandingPage";
	}
	
	@GetMapping("/About")
	public String About(Model model) {
		model.addAttribute("title", "About");
		return "About";
	}
	
	
	//login
	
	@GetMapping("/Login")
	public String login(Model model) {
		model.addAttribute("title", "Login");
		return "Login";
	}
	
	private void doAuthenticate(String userName, String password) {

		UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(userName,
				password);
		try {
			manager.authenticate(authentication);

		} catch (BadCredentialsException e) {
			throw new BadCredentialsException(" Invalid Username or Password  !!");
		}

	}
	
	@PostMapping("/loginStatus")
	public String login(@RequestParam("userName") String userName, @RequestParam("Password") String password,
			Model model) {

		try {
			this.doAuthenticate(userName, password);

			UserDetails userDetails = userDetailsService.loadUserByUsername(userName);
			String token = this.helper.generateToken(userDetails);

			Jwtresponce response = Jwtresponce.builder().jwtToken(token).userName(userDetails.getUsername()).build();
			model.addAttribute("jwtResponse", response);
			loginUser.put(userName, userName);
			return "NormalUser/User_home";
		} catch (BadCredentialsException e) {

			model.addAttribute("error_massage", "Invalid Username or Password");
			return "login";
		}
	}
	
	
	//singup
	
	@GetMapping("/SingUp")
	public String SingUp(Model model) {
		model.addAttribute("title", "SingUp");
		return "SingUp";
	}
	
	@RequestMapping(path = "/singupsuccess", method = RequestMethod.POST)
	private String singupdata(@ModelAttribute() User Users, Model model, HttpSession session) {
		model.addAttribute("title", "singup Status");

		try {
			Users.setRole("Normal");
			
			Users.setPassword(BCryptPasswordEncoder.encode(Users.getPassword()));
			boolean exest = this.UserRepo.existsById(Users.getUserName());

			if (exest == true) {
				model.addAttribute("message", "This usre name already taken please try another!!!");
				return "singup";

			} else {
				this.UserRepo.save(Users);
				model.addAttribute("message", "Successfuly added!!!");
				return "singup";
			}

		} catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("message", "Something went wrong!!!" + e.getMessage());
			model.addAttribute("error", "try different Username");
			return "singup";
		}

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	//After User login
	@GetMapping("profile")  public String profile(Model model) { 
		Set<Entry<String, String>> entrySet = loginUser.entrySet();
		for (Entry<String, String> users : entrySet) {
			String user1 = users.getKey();
			Optional<User> user = UserRepo.findById(user1);
			model.addAttribute("p", user.orElse(null));
		}
	  model.addAttribute("title", "profile"); 
	return "NormalUser/User_profile";
	 }
	 	
		
	
	@GetMapping("/Userhome")
	public String Userhome(Model model) {
		model.addAttribute("title", "Userhome");
		return "NormalUser/User_home";
	}
	
	@GetMapping("/WatchList")
	public String WatchList(Model model) {
		model.addAttribute("title", "WatchList");
		return "NormalUser/WatchList";
	}
	
	
	@RequestMapping("/EditProfile")
	public String EditProfile(Model model) {
		Set<Entry<String, String>> entrySet = loginUser.entrySet();
		for (Entry<String, String> users : entrySet) {
			String user1 = users.getKey();
			Optional<User> user = UserRepo.findById(user1);
			model.addAttribute("p", user.orElse(null));
		}
		model.addAttribute("title", "Edit profile");
		return "NormalUser/User_EditProfile";
	}

	@RequestMapping("/update")
	public String Update(@ModelAttribute() User Users, Model model) {
		model.addAttribute("title", "update");
		try {
			Users.setRole("Normal");
			Users.setPassword(BCryptPasswordEncoder.encode(Users.getPassword()));

			Set<Entry<String, String>> entrySet = loginUser.entrySet();
			for (Entry<String, String> users : entrySet) {
				String user1 = users.getKey();
				Users.setUserName(user1);
				UserRepo.save(Users);
				Optional<User> user = UserRepo.findById(user1);
				model.addAttribute("p", user.orElse(null));
			}
			model.addAttribute("title", "profile");
			return "NormalUser/User_home";
		}

		catch (Exception e) {
			System.out.print(e.getMessage());
			return "NormalUser/User_profile";
		}

	}

	
}
