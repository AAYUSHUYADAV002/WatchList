package watchListify.watchList.run;



import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import jakarta.annotation.Resource;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import watchListify.watchList.entity.Film;
import watchListify.watchList.service.FilmService;
import watchListify.watchList.service.LinkService;
import watchListify.watchList.service.WebSiteInfoService;
import watchListify.watchList.service.WebSiteService;



@Component("startupRunner")
public class StartupRunner implements CommandLineRunner, ServletContextListener {

    private ServletContext application = null;

    @Resource
    private FilmService filmService;

    @Resource
    private WebSiteInfoService webSiteInfoService;

    @Resource
    private LinkService linkService;

    @Resource
    private WebSiteService webSiteService;

    @Override
    public void contextInitialized(ServletContextEvent servletContextEvent) {
            application = servletContextEvent.getServletContext();
    }

    @Override
    public void contextDestroyed(ServletContextEvent servletContextEvent) {

    }

    @Override
    public void run(String... strings) throws Exception {
        this.loadData();
    }

    
    public void loadData() {
        application.setAttribute("newestInfoList", webSiteInfoService.list(null, 0, 10));
        Film film=new Film();
       
        application.setAttribute("newestHotFilmList", filmService.list(film, 0, 10));
        application.setAttribute("newestIndexHotFilmList", filmService.list(film, 0, 32)); 
        application.setAttribute("newestWebSiteList", webSiteService.newestList(0, 10)); 
        application.setAttribute("newestFilmList", filmService.list(null, 0, 10)); 
        application.setAttribute("linkList", linkService.listAll()); 
    }
}